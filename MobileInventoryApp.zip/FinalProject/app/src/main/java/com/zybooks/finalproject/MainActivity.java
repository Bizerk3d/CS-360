/**
 * This class enables the first screen users see to register if they're a new user or to click
 * a button that takes them to the existing user login activity
 */
package com.zybooks.finalproject;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    EditText username, password, repassword;
    Button btnSignUp, btnSignIn;
    UserDBHelper myUserDb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        username = (EditText)findViewById(R.id.username);
        password = (EditText)findViewById(R.id.password);
        repassword = (EditText)findViewById(R.id.repassword);

        btnSignUp = (Button)findViewById(R.id.btnSignUp);
        btnSignIn = (Button)findViewById(R.id.btnSignIn);

        myUserDb = new UserDBHelper(this);

        // sets up listener logic for registration
        btnSignUp.setOnClickListener(view -> {
            String user = username.getText().toString();
            String pass = password.getText().toString();
            String repass = repassword.getText().toString();

            // checks for empty fields
            if (user.equals("") || pass.equals("") || repass.equals("")) {
                Toast.makeText(MainActivity.this, "Please fill out all the fields", Toast.LENGTH_SHORT).show();
            }
            else {
                // if passwords match checks to see if user already exists in table
                if (pass.equals(repass)) {
                    Boolean userCheckResult = myUserDb.checkUsername(user);
                    if (!userCheckResult) {
                        Boolean regResult = myUserDb.insertUser(user, pass);
                        // user registered if pw match and user not already found
                        if (regResult) {
                            Toast.makeText(MainActivity.this, "Registration Successful!", Toast.LENGTH_SHORT).show();
                            // moves user to login activity automatically after successful registration
                            Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
                            startActivity(intent);
                        }
                    }
                    // error msg if user exists
                    else {
                        Toast.makeText(MainActivity.this, "User already exists - please sign in.", Toast.LENGTH_SHORT).show();
                    }
                }
                // error msg if pw don't match
                else {
                    Toast.makeText(MainActivity.this, "Passwords do not match - please try again.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnSignIn.setOnClickListener(view -> {
            Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
            startActivity(intent);
        });
    }
}