/**
 * This class contains various helper functions to enable creation and upgrading of login db, as well
 * as functions that allow users to be inserted, or to check credentials
 */
package com.zybooks.finalproject;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

// db for users and helper functions
public class UserDBHelper extends SQLiteOpenHelper {
    public UserDBHelper(Context context) {
        super(context, "Login.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase myUserDb) {
        myUserDb.execSQL("create Table users(username Text primary key, password Text)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase myUserDb, int i, int i1) {
        myUserDb.execSQL("drop Table if exists users");
    }

    // add new user
    public Boolean insertUser(String username, String password) {
        SQLiteDatabase myUserDb = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("username", username);
        contentValues.put("password", password);
        long result = myUserDb.insert("users", null, contentValues);
        return result != -1;
    }

    // check for existing user in table
    public Boolean checkUsername(String username) {
        SQLiteDatabase myUserDb = this.getWritableDatabase();
        Cursor cursor = myUserDb.rawQuery("select * from users where username = ?", new String[] {username});
        return cursor.getCount() > 0;
    }

    // authenticate user and pw against table
    public Boolean checkUsernamePassword (String username, String password) {
        SQLiteDatabase myUserDb = this.getWritableDatabase();
        Cursor cursor = myUserDb.rawQuery("select * from users where username = ? and password = ?", new String[] {username, password});
        return cursor.getCount() > 0;
    }
}
