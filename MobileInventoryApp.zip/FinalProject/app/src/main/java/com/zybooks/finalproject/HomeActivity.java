/**
 * This class houses views for main Inventory page where items are added and accessed for editing/deletion
 */
package com.zybooks.finalproject;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class HomeActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    ImageView empty_imageview;
    TextView no_data;

    boolean hasPermission;
    private static final int SMS_PERMISSION_CODE = 100;
    DBHelper DB;
    ArrayList<String> itemName, quantity;
    CustomAdapter customAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        recyclerView = findViewById(R.id.recyclerView);

        DB = new DBHelper(HomeActivity.this);
        itemName = new ArrayList<>();
        quantity = new ArrayList<>();

        empty_imageview = findViewById(R.id.empty_imageview);
        no_data = findViewById(R.id.no_data);

        storeDataInArrays();

        customAdapter = new CustomAdapter(HomeActivity.this, this, itemName, quantity);
        recyclerView.setAdapter(customAdapter);
        // set columns for grid layout in recycler view
        int numColumns = 3;
        recyclerView.setLayoutManager(new GridLayoutManager(HomeActivity.this, numColumns));

        Button btnPermission = findViewById(R.id.btnPermission);

        FloatingActionButton addItem = findViewById(R.id.addItem);

        addItem.setOnClickListener(view -> {
            Intent intent = new Intent(HomeActivity.this, NewItemActivity.class);
            startActivity(intent);
        });

        // listener for permission button
        btnPermission.setOnClickListener(v -> checkPermission(Manifest.permission.SEND_SMS, SMS_PERMISSION_CODE));
        // check if user already given permission
        checkPermission(Manifest.permission.SEND_SMS, 100);
        permissionGranted(hasPermission);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == 1){
            recreate();
        }
    }

    // empty view if db is empty or places items in arraylists
    void storeDataInArrays() {
        Cursor cursor = DB.readAllData();
        if (cursor.getCount() == 0) {
            empty_imageview.setVisibility(View.VISIBLE);
            no_data.setVisibility(View.VISIBLE);
        }
        else {
            while (cursor.moveToNext()) {
                itemName.add(cursor.getString(0));
                quantity.add(cursor.getString(1));
            }
            empty_imageview.setVisibility(View.GONE);
            no_data.setVisibility(View.GONE);
        }
    }

    // Function that checks and requests permission
    public void checkPermission(String permission, int requestCode) {
        if (ContextCompat.checkSelfPermission(HomeActivity.this, permission) == PackageManager.PERMISSION_DENIED) {
            // Requesting the permission
            ActivityCompat.requestPermissions(HomeActivity.this, new String[]{permission}, requestCode);
        }
        else {
            hasPermission = true;
            permissionGranted(true);
        }
    }

    // function to check if sms permission given
    public void permissionGranted(boolean hasPermission) {
        Button btnPermission = findViewById(R.id.btnPermission);
        if (hasPermission) {
            btnPermission.setVisibility(View.GONE); // hides button if permission already given
        }
    }

    // Function called when user accepts or declines permission
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode,
                permissions,
                grantResults);

        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(HomeActivity.this, "SMS Permission Granted", Toast.LENGTH_SHORT).show();
                hasPermission = true;
                permissionGranted(true);
            }
            else {
                Toast.makeText(HomeActivity.this, "SMS Permission Denied", Toast.LENGTH_SHORT).show();
            }
        }
    }
}