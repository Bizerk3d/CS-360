/**
 * This class is used to add new items into the inventory and is called with add button from Home
 * activity page
 */
package com.zybooks.finalproject;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class NewItemActivity extends AppCompatActivity {

    EditText itemName, quantity;
    Button submit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_item);

        itemName = findViewById(R.id.itemName);
        quantity = findViewById(R.id.quantity);
        submit = findViewById(R.id.submit);

        submit.setOnClickListener(view -> {
            String item = itemName.getText().toString().trim();
            String qty = quantity.getText().toString().trim();

            DBHelper DB = new DBHelper(getApplicationContext());

            // check for empty fields
            if (item.equals("") || qty.equals("")) {
                Toast.makeText(NewItemActivity.this, "Please fill out all the fields", Toast.LENGTH_SHORT).show();
            }
            else {
                Boolean itemResult = DB.checkItemName(itemName.getText().toString());
                // check if item already in inventory db
                if (itemResult) {
                    Toast.makeText(NewItemActivity.this, "Item Already in Inventory", Toast.LENGTH_SHORT).show();
                } else {
                    // inserts item if not already in db
                    DB.insertItem(item, Integer.valueOf(qty));
                    Toast.makeText(NewItemActivity.this, "Item Added", Toast.LENGTH_SHORT).show();
                }
                // takes user back to home page of inventory
                Intent intent = new Intent(NewItemActivity.this, HomeActivity.class);
                startActivity(intent);
                // calls method to send msg if any items have zero quantity
                DB.sendSMS();
            }
        });
    }
}