/**
 * This class enables our recycler view for the grid layout of items on the Home activity
 */
package com.zybooks.finalproject;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.GridLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class CustomAdapter extends RecyclerView.Adapter<CustomAdapter.MyViewHolder> {

    private Context context;
    private Activity act;
    private ArrayList itemName, quantity;

    CustomAdapter(Activity act, Context context, ArrayList itemName, ArrayList quantity) {
        this.act = act;
        this.context = context;
        this.itemName = itemName;
        this.quantity = quantity;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.my_row, parent, false);
        return new MyViewHolder(view);
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    public void onBindViewHolder(@NonNull final MyViewHolder holder, @SuppressLint("RecyclerView") final int position) {
        holder.itemName.setText(String.valueOf(itemName.get(position)));
        holder.quantity.setText(String.valueOf(quantity.get(position)));
        // on click for recyclerview
        holder.mainLayout.setOnClickListener(view -> {
            Intent intent = new Intent(context, ItemActivity.class);
            intent.putExtra("itemName", String.valueOf(itemName.get(position)));
            intent.putExtra("quantity", String.valueOf(quantity.get(position)));
            act.startActivityForResult(intent, 1);
        });
    }

    @Override
    public int getItemCount() {
        return itemName.size();
    }

    // grid layout viewholder
    public class MyViewHolder extends RecyclerView.ViewHolder {

        TextView itemName, quantity;
        GridLayout mainLayout;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            itemName = itemView.findViewById(R.id.itemName);
            quantity = itemView.findViewById(R.id.quantity);
            mainLayout = itemView.findViewById(R.id.mainLayout);
            // animations
            Animation translate_anim = AnimationUtils.loadAnimation(context, R.anim.translate_anim);
            mainLayout.setAnimation(translate_anim);
        }
    }
}
