/**
 * This class houses displays editable fields for editing existing db items and allows user to
 * update item names or quantities, or to delete an item
 */
package com.zybooks.finalproject;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.util.concurrent.atomic.AtomicReference;

public class ItemActivity extends AppCompatActivity {

    EditText itemName, quantity;
    Button delete, update;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item);

        itemName = findViewById(R.id.itemName);
        quantity = findViewById(R.id.quantity);

        delete = findViewById(R.id.deleteBtn);
        update = findViewById(R.id.save);

        Intent intent = getIntent();
        AtomicReference<String> name = new AtomicReference<>(intent.getExtras().getString("itemName"));
        AtomicReference<String> qty = new AtomicReference<>(intent.getExtras().getString("quantity"));

        itemName.setText(name.get());
        quantity.setText(qty.get());

        // listener for updates/save changes button
        update.setOnClickListener(view -> {
            DBHelper DB = new DBHelper(ItemActivity.this);
            name.set(itemName.getText().toString().trim());
            qty.set(quantity.getText().toString().trim());
            DB.updateItem(name.get(), Integer.valueOf(qty.get()));
            Toast.makeText(this, "Changes Saved", Toast.LENGTH_SHORT).show();
            Intent mIntent = new Intent(ItemActivity.this, HomeActivity.class);
            startActivity(mIntent);
            DB.sendSMS();
        });

        delete.setOnClickListener(view -> confirmDialog());
    }

    // verify deletion
    void confirmDialog() {
        String name = itemName.getText().toString();
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Delete " + name + " ?");
        builder.setMessage("Are you sure you want to delete " + name + " ?");
        builder.setPositiveButton("Yes", (dialogInterface, i) -> {
            DBHelper DB = new DBHelper(ItemActivity.this);
            DB.deleteItem(name);
            Toast.makeText(this, "Item Deleted Successfully", Toast.LENGTH_SHORT).show();
            finish();
        });
        builder.setNegativeButton("No", (dialogInterface, i) -> {

        });
        builder.create().show();
    }
}