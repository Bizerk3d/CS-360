/**
 * This class contains various helper functions to enable creation, upgrade, insertion, editing, and deletion
 * of database items
 */
package com.zybooks.finalproject;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.telephony.SmsManager;

public class DBHelper extends SQLiteOpenHelper {
    public DBHelper(Context context) { super(context, "Inventory.db", null, 1); }

    @Override
    public void onCreate(SQLiteDatabase DB) {
        DB.execSQL("create Table Inventory(_id INTEGER primary key autoincrement, ItemName TEXT, Quantity INTEGER)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase DB, int i, int i1) {
        DB.execSQL("drop Table if exists Inventory");
        onCreate(DB);
    }

    // add function
    Boolean insertItem (String ItemName, Integer Quantity) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("ItemName", ItemName);
        contentValues.put("Quantity", Quantity);
        long results = db.insert("Inventory", null, contentValues);
        return results != -1;
    }

    // checks for existing item in db
    public Boolean checkItemName(String itemName) {
        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor = DB.rawQuery("select * from Inventory where itemName = ?", new String[] {itemName});
        return cursor.getCount() > 0;
    }

    // reads data for recycler view grid
    Cursor readAllData(){
        String query = "SELECT * FROM Inventory";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;

        if(db != null){
            cursor = db.rawQuery(query, null);
        }
        return cursor;
    }

    // checks for low inventory level
    Cursor checkInvLevels(){
        String query = "SELECT * FROM Inventory WHERE Quantity <= 0";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;

        if(db != null){
            cursor = db.rawQuery(query, null);
        }
        return cursor;
    }

    // sends msg if inventory is low
    public void sendSMS() {
        String message = "Inventory Levels Low!";
        String number = "5555215554";
        Cursor cursor = checkInvLevels();
        if ((cursor.getCount() >= 1)) {
            SmsManager mySmsManager = SmsManager.getDefault();
            mySmsManager.sendTextMessage(number,null, message, null, null);
        }
    }

    // update function
    boolean updateItem (String ItemName, Integer Quantity) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("ItemName", ItemName);
        contentValues.put("Quantity", Quantity);
        Cursor cursor = db.rawQuery("Select * from Inventory where ItemName = ?", new String[] {ItemName});
        if (cursor.getCount() > 0) {
            long results = db.update("Inventory", contentValues, "ItemName = ?", new String[] {ItemName});
            return results != -1;
        }
        return false;
    }

    // delete function
    public Boolean deleteItem (String ItemName) {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("Select * from Inventory where ItemName = ?", new String[]{ItemName});
        if (cursor.getCount() > 0) {
            long results = db.delete("Inventory", "ItemName = ?", new String[]{ItemName});
            return results != -1;
        }
        else {
            return false;
        }
    }
}
